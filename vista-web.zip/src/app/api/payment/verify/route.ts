import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { createZibalService } from '@/lib/zibal'
import { env } from '@/lib/env'

export async function POST(request: NextRequest) {
  let trackId: number | null = null
  
  try {
    const body = await request.json()
    trackId = body.trackId
    const { userId, plan } = body

    if (!trackId || !userId || !plan) {
      return NextResponse.json(
        { error: 'TrackId, User ID, and plan are required' },
        { status: 400 }
      )
    }

    // بررسی service role key
    if (!env.SUPABASE_SERVICE_ROLE_KEY) {
      console.error('SUPABASE_SERVICE_ROLE_KEY is not defined')
      return NextResponse.json(
        { error: 'Service role key not configured' },
        { status: 500 }
      )
    }

    // ایجاد کلاینت ادمین
    const adminSupabase = createClient(
      env.NEXT_PUBLIC_SUPABASE_URL,
      env.SUPABASE_SERVICE_ROLE_KEY
    )

    // بررسی اینکه آیا این پرداخت قبلاً verify شده یا نه
    const { data: existingPayment } = await adminSupabase
      .from('payment_logs')
      .select('status')
      .eq('track_id', trackId)
      .eq('user_id', userId)
      .single()

    if (existingPayment?.status === 'verified') {
      return NextResponse.json(
        { error: 'این پرداخت قبلاً تایید شده است' },
        { status: 400 }
      )
    }

    // ایجاد سرویس زیبال و تایید پرداخت
    const zibalService = createZibalService()
    const verifyResponse = await zibalService.verifyPayment(Number(trackId))

    // آپدیت لاگ پرداخت
    await adminSupabase
      .from('payment_logs')
      .update({
        status: 'verified',
        ref_number: verifyResponse.refNumber,
        card_number: verifyResponse.cardNumber,
        paid_at: verifyResponse.paidAt,
        verified_at: new Date().toISOString(),
      })
      .eq('track_id', trackId)

    // آپدیت پروفایل با تیک طلایی
    const { data: profile, error: updateError } = await adminSupabase
      .from('profiles')
      .update({
        is_verified: true,
        verification_type: 'goldTick',
        role: 'premium',
        updated_at: new Date().toISOString(),
      })
      .eq('id', userId)
      .select()
      .single()

    if (updateError) {
      console.error('Error updating profile:', updateError)
      return NextResponse.json(
        { error: 'Failed to update profile', details: updateError.message },
        { status: 500 }
      )
    }

    console.log('Profile updated successfully with goldTick:', profile)

    return NextResponse.json(
      {
        success: true,
        message: 'پرداخت با موفقیت تایید شد و تیک طلایی فعال شد',
        profile,
        payment: {
          refNumber: verifyResponse.refNumber,
          amount: verifyResponse.amount / 10, // تبدیل ریال به تومان
          paidAt: verifyResponse.paidAt,
        },
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Error verifying payment:', error)
    
    // در صورت خطا، لاگ پرداخت را به عنوان failed علامت‌گذاری می‌کنیم
    if (trackId) {
      try {
        const adminSupabase = createClient(
          env.NEXT_PUBLIC_SUPABASE_URL,
          env.SUPABASE_SERVICE_ROLE_KEY
        )
        
        await adminSupabase
          .from('payment_logs')
          .update({
            status: 'failed',
            error_message: error instanceof Error ? error.message : 'Unknown error',
          })
          .eq('track_id', trackId)
      } catch (logError) {
        console.error('Error updating payment log:', logError)
      }
    }

    return NextResponse.json(
      {
        error: 'خطا در تایید پرداخت',
        details: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    )
  }
}
