'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';

import { useAuth } from '@/hooks/useAuth';
import { createClient } from '@/lib/supabase/client';
import { useRealtimeMessages } from '@/lib/hooks/use-realtime-messages';

interface ConversationListItem {
    id: string;
    otherUserId: string;
    otherUserName: string;
    otherUserAvatar?: string | null;
    lastMessage?: string | null;
    lastMessageTime?: string | null;
    unreadCount: number;
    updatedAt: string;
}

export default function MessagesPage() {
    const router = useRouter();
    const { user, loading } = useAuth();
    const supabase = useMemo(() => createClient(), []);

    const [conversations, setConversations] = useState<ConversationListItem[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
    const messagesContainerRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        if (loading) return;

        if (!user) {
            router.replace('/auth?redirect=/messages');
            return;
        }

        let ignore = false;

        const fetchConversations = async () => {
            try {
                setIsLoading(true);
                setError(null);

                const { data: participantRows, error: participantError } = await supabase
                    .from('conversation_participants')
                    .select(
                        `
              conversation_id,
              conversations!inner (
                id,
                last_message,
                last_message_time,
                updated_at,
                last_activity
              )
            `,
                    )
                    .eq('user_id', user.id)
                    .order('updated_at', { referencedTable: 'conversations', ascending: false });

                if (participantError) {
                    throw participantError;
                }

                if (ignore || !participantRows || participantRows.length === 0) {
                    setConversations([]);
                    setSelectedConversationId(null);
                    return;
                }

                const conversationIds = participantRows
                    .map(row => row.conversation_id)
                    .filter((value): value is string => Boolean(value));

                if (conversationIds.length === 0) {
                    setConversations([]);
                    setSelectedConversationId(null);
                    return;
                }

                const { data: participantsByConversation, error: participantsError } = await supabase
                    .from('conversation_participants')
                    .select('conversation_id, user_id')
                    .in('conversation_id', conversationIds);

                if (participantsError) {
                    throw participantsError;
                }

                const otherUserIdsSet = new Set<string>();
                const otherUserByConversation = new Map<string, string>();

                (participantsByConversation ?? []).forEach(participant => {
                    if (!participant.conversation_id || !participant.user_id) {
                        return;
                    }

                    if (participant.user_id !== user.id) {
                        otherUserIdsSet.add(participant.user_id);
                        otherUserByConversation.set(participant.conversation_id, participant.user_id);
                    }
                });

                const otherUserIds = Array.from(otherUserIdsSet);

                const profileMap = new Map<string, { name: string; avatar: string | null }>();

                if (otherUserIds.length > 0) {
                    const { data: profiles, error: profilesError } = await supabase
                        .from('profiles')
                        .select('id, full_name, username, avatar_url')
                        .in('id', otherUserIds);

                    if (profilesError) {
                        throw profilesError;
                    }

                    (profiles ?? []).forEach(profile => {
                        if (profile.id) {
                            profileMap.set(profile.id, {
                                name: profile.full_name || profile.username || 'کاربر ناشناس',
                                avatar: profile.avatar_url,
                            });
                        }
                    });
                }

                const normalized = participantRows.reduce<ConversationListItem[]>((acc, row) => {
                    const conversationId = row.conversation_id;
                    const conversationRaw = row.conversations;
                    const conversation = Array.isArray(conversationRaw) ? conversationRaw[0] : conversationRaw;

                    if (!conversationId || !conversation?.id) {
                        return acc;
                    }

                    const otherUserId = otherUserByConversation.get(conversationId);
                    const profileInfo = otherUserId ? profileMap.get(otherUserId) : undefined;

                    acc.push({
                        id: conversation.id as string,
                        otherUserId: otherUserId ?? 'unknown',
                        otherUserName: profileInfo?.name ?? 'کاربر ناشناس',
                        otherUserAvatar: profileInfo?.avatar ?? null,
                        lastMessage: (conversation as { last_message?: string | null }).last_message ?? null,
                        lastMessageTime: (conversation as { last_message_time?: string | null }).last_message_time ?? null,
                        unreadCount: 0,
                        updatedAt:
                            (conversation as { updated_at?: string | null }).updated_at ??
                            (conversation as { last_message_time?: string | null }).last_message_time ??
                            (conversation as { last_activity?: string | null }).last_activity ??
                            '',
                    });

                    return acc;
                }, []);

                normalized.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
                setConversations(normalized);
                if (!selectedConversationId && normalized.length > 0) {
                    setSelectedConversationId(normalized[0].id);
                }
            } catch (err) {
                const message =
                    err instanceof Error
                        ? err.message
                        : typeof err === 'object' && err !== null
                            ? JSON.stringify(err)
                            : 'بارگیری گفتگوها با مشکل مواجه شد.';

                console.error('Failed to load conversations:', err);
                setError(message);
            } finally {
                if (!ignore) {
                    setIsLoading(false);
                }
            }
        };

        fetchConversations();

        return () => {
            ignore = true;
        };
    }, [loading, router, selectedConversationId, supabase, user]);

    const activeConversation = selectedConversationId
        ? conversations.find(conversation => conversation.id === selectedConversationId) ?? null
        : null;

    const { messages, isLoading: isMessagesLoading } = useRealtimeMessages({
        conversationId: selectedConversationId ?? '',
        userId: user?.id ?? '',
    });

    useEffect(() => {
        if (!messagesContainerRef.current) return;
        messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
    }, [messages, selectedConversationId]);

    if (loading) {
        return (
            <div className="flex h-full items-center justify-center p-6">
                <div className="rounded-xl border border-zinc-200 p-6 text-sm text-gray-500 dark:border-zinc-800 dark:text-gray-400">
                    در حال بررسی حساب کاربری...
                </div>
            </div>
        );
    }

    if (!user) {
        return null;
    }

    return (
        <div className="flex h-screen max-h-screen flex-col gap-6 overflow-hidden p-6">
            <div>
                <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">پیام‌ها</h1>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">گفتگوهای اخیر شما</p>
            </div>

            <div className="flex flex-1 gap-4 overflow-hidden">
                <div className="flex h-full w-80 flex-col overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
                    <div className="border-b border-zinc-200 p-4 dark:border-zinc-800">
                        <h2 className="text-base font-medium text-gray-900 dark:text-white">گفتگوها</h2>
                    </div>
                    <div className="flex-1 divide-y divide-zinc-200 overflow-y-auto dark:divide-zinc-800">
                        {isLoading ? (
                            <div className="p-6 text-center text-sm text-gray-500 dark:text-gray-400">در حال بارگیری...</div>
                        ) : error ? (
                            <div className="p-6 text-center text-sm text-red-500 dark:text-red-400">{error}</div>
                        ) : conversations.length === 0 ? (
                            <div className="p-6 text-center text-sm text-gray-500 dark:text-gray-400">هنوز گفتگویی ندارید.</div>
                        ) : (
                            conversations.map(conversation => {
                                const isActive = conversation.id === selectedConversationId;

                                return (
                                    <button
                                        key={conversation.id}
                                        type="button"
                                        onClick={() => setSelectedConversationId(conversation.id)}
                                        className={`flex w-full flex-col gap-1 p-4 text-right transition ${isActive
                                            ? 'bg-indigo-50 dark:bg-indigo-900/30'
                                            : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/50'
                                            }`}
                                    >
                                        <div className="flex items-center justify-between text-sm font-medium text-gray-900 dark:text-white">
                                            <span>{conversation.otherUserName}</span>
                                            {conversation.unreadCount > 0 && (
                                                <span className="rounded-full bg-indigo-600 px-2 py-0.5 text-xs font-semibold text-white">
                                                    {conversation.unreadCount}
                                                </span>
                                            )}
                                        </div>
                                        <div className="line-clamp-1 text-sm text-gray-500 dark:text-gray-400">
                                            {conversation.lastMessage || 'بدون پیام'}
                                        </div>
                                        <div className="text-xs text-gray-400 dark:text-gray-500">
                                            {conversation.lastMessageTime
                                                ? new Date(conversation.lastMessageTime).toLocaleString('fa-IR')
                                                : ''}
                                        </div>
                                    </button>
                                );
                            })
                        )}
                    </div>
                </div>

                <div className="flex h-full flex-1 flex-col overflow-hidden rounded-2xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
                    {activeConversation ? (
                        <>
                            <div className="flex items-center justify-between border-b border-zinc-200 p-4 dark:border-zinc-800">
                                <div>
                                    <h2 className="text-base font-medium text-gray-900 dark:text-white">
                                        {activeConversation.otherUserName}
                                    </h2>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">
                                        آخرین فعالیت:{' '}
                                        {activeConversation.updatedAt
                                            ? new Date(activeConversation.updatedAt).toLocaleString('fa-IR')
                                            : 'نامشخص'}
                                    </p>
                                </div>
                            </div>

                            <div className="flex-1 space-y-3 overflow-y-auto p-4" ref={messagesContainerRef}>
                                {isMessagesLoading ? (
                                    <div className="flex h-full items-center justify-center text-sm text-gray-500 dark:text-gray-400">
                                        در حال بارگیری پیام‌ها...
                                    </div>
                                ) : messages.length === 0 ? (
                                    <div className="flex h-full items-center justify-center text-sm text-gray-500 dark:text-gray-400">
                                        هنوز پیامی در این گفتگو ارسال نشده است.
                                    </div>
                                ) : (
                                    [...messages].reverse().map(message => {
                                        const isOwn = message.senderId === user?.id;

                                        return (
                                            <div
                                                key={message.id}
                                                className={`max-w-[75%] rounded-2xl px-4 py-2 text-sm ${isOwn
                                                    ? 'ml-auto bg-indigo-600 text-white'
                                                    : 'mr-auto bg-zinc-100 text-gray-900 dark:bg-zinc-800 dark:text-gray-100'
                                                    }`}
                                            >
                                                <p className="whitespace-pre-wrap leading-relaxed">{message.content}</p>
                                                <span className="mt-1 block text-xs opacity-70">
                                                    {new Date(message.createdAt).toLocaleString('fa-IR')}
                                                </span>
                                            </div>
                                        );
                                    })
                                )}
                            </div>

                            <div className="border-t border-zinc-200 p-4 dark:border-zinc-800">
                                <form className="flex items-center gap-3">
                                    <input
                                        type="text"
                                        placeholder="پیام خود را بنویسید..."
                                        className="flex-1 rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm text-gray-900 placeholder:text-gray-400 focus:border-indigo-500 focus:outline-none dark:border-zinc-700 dark:bg-zinc-800 dark:text-gray-100"
                                        disabled
                                    />
                                    <button
                                        type="button"
                                        className="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-medium text-white opacity-60"
                                        disabled
                                    >
                                        ارسال
                                    </button>
                                </form>
                                <p className="mt-2 text-xs text-gray-400 dark:text-gray-500">
                                    (در نسخه فعلی، ارسال پیام از طریق وب هنوز فعال نشده است.)
                                </p>
                            </div>
                        </>
                    ) : (
                        <div className="flex h-full items-center justify-center p-8 text-center text-sm text-gray-500 dark:text-gray-400">
                            یک گفتگو را انتخاب کنید تا پیام‌ها نمایش داده شوند.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

